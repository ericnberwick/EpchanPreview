clear;

load('C:/Projects/Futures_data/inputDataDaily_ES_1615', 'tday', 'contracts', 'cl');

es=NaN(size(cl));

for c=1:length(contracts)
    
    
    
end