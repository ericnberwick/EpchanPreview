rm(list=ls()) # clear workspace
backshift <- function(mylag, x) {
  rbind(matrix(NaN, mylag, ncol(x)), as.matrix(x[1:(nrow(x)-mylag),]))
  
}
#install.packages('pls')
library("pls")
library('zoo')
source('calculateReturns.R')
#source('backshift.R')

lookback <- 252 #  use lookback days as estimation (training) period for determining factor exposures.
numFactors <- 5 
topN <- 50 # for trading strategy, long stocks with topN expected 1-day returns.

data1 <- read.csv("IJR_20080114.csv") # Tab-delimited
cl <- data.matrix(data1[, 2:ncol(data1)])

cl[ is.nan(cl) ] <- NA
tday <- data.matrix(data1[, 1])
mycls <- na.fill(cl, type="locf", nan=NA, fill=NA)
end_loop <- nrow(mycls)
positionsTable <- matrix(0, end_loop, ncol(mycls))

dailyret <- calculateReturns(mycls, 1)
dailyret[is.nan(dailyret)] <- 0
dailyret <- dailyret[1:end_loop,]

for (it in (lookback+2):end_loop) {
  R <- dailyret[(it-lookback+2):it,] 
   hasData <- which(complete.cases(t(R)))
  R <- R[, hasData ]
 PCA <- prcomp(t(R))
 X <- t(PCA$x[1:numFactors,])
  Rexp <- rep(0,ncol(R))
  for (s in 1:ncol(R)){
    reg_result <- lm(R[,s] ~  X  )
    pred <- predict(reg_result)
    pred[is.nan(pred)] <- 0
    Rexp[s] <-  sum(pred)
  }
  result <- sort(Rexp, index.return=TRUE)
  
  positionsTable[it, hasData[result$ix[1:topN]] ] = -1
  positionsTable[it, hasData[result$ix[(length(result$ix)-topN-1):length(result$ix)]] ] = 1
  
}

capital <- rowSums(abs(backshift(1, positionsTable)), na.rm = TRUE, dims = 1)
ret <- rowSums(backshift(1, positionsTable)*dailyret, na.rm = TRUE, dims = 1)/capital

avgret <- 252*mean(ret, na.rm = TRUE)
avgstd  <- sqrt(252)*sd(ret, na.rm = TRUE)
Sharpe = avgret/avgstd

print(avgret)
print(avgstd)
print(Sharpe)