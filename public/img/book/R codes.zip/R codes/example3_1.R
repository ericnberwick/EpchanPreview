#tidyverse contains the packages tidyr, ggplot2, dplyr,
# readr, purrr and tibble
# install.packages("tidyverse")
# install.packages("lubridate")
# install.packages("readxl")
# install.packages("highcharter")
# install.packages("tidyquant")
# install.packages("timetk")
# install.packages("tibbletime")
# install.packages("quantmod")
# install.packages("PerformanceAnalytics")
# install.packages("scales")
library(tidyverse)
library(lubridate)
library(readxl)
library(highcharter)
library(tidyquant)
library(timetk)
library(tibbletime)
library(quantmod)
library(PerformanceAnalytics)
library(scales) 

symbols <- c("SPY","EFA", "IJS", "EEM","AGG")

prices <-
  getSymbols(symbols,
             src = 'yahoo',
             from = "2012-12-31",
             to = "2017-12-31",
             auto.assign = TRUE,
             warnings = FALSE) 

print(SPY)
