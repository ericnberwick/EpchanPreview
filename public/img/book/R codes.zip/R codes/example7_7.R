rm(list=ls()) # clear workspace

# Need the lubridate package for its dates handling
# install.packages('lubridate')
library('lubridate')
source('calculateReturns.R')
source('backshift.R')
source('fwdshift.R')


data1 <- read.delim("SPX_20071123.txt") # Tab-delimited

cl <- data.matrix(data1[, 2:ncol(data1)])
tday <- ymd(data.matrix(data1[, 1])) # dates in lubridate format

years <- year(tday)
months <- month(tday)

years <- as.matrix(years, length(years), 1)
months <- as.matrix(months, length(months), 1)

nextdaymonth <- fwdshift(1, months)

eom <- which(months!=nextdaymonth) # End of month indices.

monret <- calculateReturns(cl[eom,], 1) # monthly returns

positions <- matrix(0, nrow(monret), ncol(monret))

for (m in 14:nrow(monret)) {
  prevYearSortIdx <- order(monret[m-12,],  na.last = NA)
  prevYearSortIdx <- setdiff(prevYearSortIdx, which(!is.finite(cl[eom[m-1],]))) # Note setdiff in R does not re-sort data. It is equivalent to setdiff(x, y, 'stable') in Matlab 
  
  topN <- round(length(prevYearSortIdx)/10) # buy stocks with top decile of returns, and sell stocks of bottom decile

  positions[m-1, prevYearSortIdx[1:topN]] <- -1
  positions[m-1, prevYearSortIdx[(length(prevYearSortIdx)-topN+1):length(prevYearSortIdx)]] <- 1
    
}

ret <- rowSums(backshift(1, positions)*monret, na.rm = TRUE)/rowSums(abs(backshift(1, positions)), na.rm=TRUE)
ret <- ret[-(1:13)]
avgannret <- 12*mean(ret, na.rm = TRUE)
avgannret # -0.01139674
sharpe <- sqrt(12)*mean(ret, na.rm = TRUE)/sd(ret, na.rm=TRUE)
sharpe # -0.1095098

                                                                         
                                                                         