rm(list=ls()) # clear workspace
# setwd("C:/Users/Ernest/Dropbox/Book") # set working directory to where data is

# Need the zoo package for its na.locf function
# Need the zoo package for its na.locf function
# install.packages('zoo')
library('zoo')
source('calculateReturns.R')
source('calculateMaxDD.R')
source('backshift.R')

data1 <- read.delim("GLD.txt") # Tab-delimited
data_sort1 <- data1[order(as.Date(data1[,1], '%m/%d/%Y')),] # sort in ascending order of dates (1st column of data)
tday1 <- as.integer(format(as.Date(data_sort1[,1], '%m/%d/%Y'), '%Y%m%d'))
adjcls1 <- data_sort1[,ncol(data_sort1)]

data2 <- read.delim("GDX.txt") # Tab-delimited
data_sort2 <- data2[order(as.Date(data2[,1], '%m/%d/%Y')),] # sort in ascending order of dates (1st column of data)
tday2 <- as.integer(format(as.Date(data_sort2[,1], '%m/%d/%Y'), '%Y%m%d'))
adjcls2 <- data_sort2[,ncol(data_sort2)]

# find the intersection of the two data sets
tday <- intersect(tday1, tday2)
adjcls1 <- adjcls1[tday1 %in% tday]
adjcls2 <- adjcls2[tday2 %in% tday]

#  define indices for training and test sets
trainset <- 1:252
testset <- length(trainset)+1:length(tday)

# determines the hedge ratio on the trainset
result <- lm(adjcls1 ~ 0 + adjcls2, subset=trainset  )
hedgeRatio <- coef(result) # 1.631

spread <- adjcls1-hedgeRatio*adjcls2 # spread = GLD - hedgeRatio*GDX 
plot(spread)
dev.new()
plot(spread[trainset])
dev.new()
plot(spread[testset])

# mean  of spread on trainset
spreadMean <- mean(spread[trainset]) # 0.05219624
# standard deviation of spread on trainset
spreadStd <- sd(spread[trainset]) # 1.948731

zscore <- (spread-spreadMean)/spreadStd

longs <- zscore <= -2 # buy spread when its value drops below 2 standard deviations.
shorts <- zscore >= 2 # short spread when its value rises above 2 standard deviations.

#  exit any spread position when its value is within 1 standard deviation of its mean.
longExits   <- zscore >= -1 
shortExits <- zscore <= 1 

posL <- matrix(NaN, length(tday), 2) # long positions
posS <- matrix(NaN, length(tday), 2) # short positions

# initialize to 0
posL[1,] <- 0
posS[1,] <- 0

posL[longs, 1] <- 1
posL[longs, 2] <- -1
posS[shorts, 1] <- -1
posS[shorts, 2] <- 1

posL[longExits, 1] <- 0
posL[longExits, 2] <- 0
posS[shortExits, 1] <- 0
posS[shortExits, 2] <- 0

# ensure existing positions are carried forward unless there is an exit signal
posL <- zoo::na.locf(posL)
posS <- zoo::na.locf(posS)

positions <- posL + posS

cl  <- cbind(adjcls1, adjcls2) # last row is [385,]   77.32   46.36
# daily returns of price series
dailyret <- calculateReturns(cl, 1) #  last row is [385,] -0.0122636689 -0.0140365802

pnl <- rowSums(backshift(1, positions)*dailyret)

sharpeRatioTrainset <- sqrt(252)*mean(pnl[trainset], na.rm = TRUE)/sd(pnl[trainset], na.rm = TRUE)
sharpeRatioTrainset # 2.327844

sharpeRatioTestset <- sqrt(252)*mean(pnl[testset], na.rm = TRUE)/sd(pnl[testset], na.rm = TRUE)
sharpeRatioTestset # 1.508212
