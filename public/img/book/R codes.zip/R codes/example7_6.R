rm(list=ls()) # clear workspace

# Need the lubridate package for its dates handling
# install.packages('lubridate')
library('lubridate')
source('calculateReturns.R')
source('fwdshift.R')

onewaytcost <- 5/10000 # 5bps one way transaction cost

data1 <- read.delim("IJR_20080131.txt") # Tab-delimited
cl <- data.matrix(data1[, 2:ncol(data1)])
tday <- ymd(data.matrix(data1[, 1])) # dates in lubridate format

years <- year(tday)
months <- month(tday)

years <- as.matrix(years, length(years), 1)
months <- as.matrix(months, length(months), 1)

nextdayyear <- fwdshift(1, years)
nextdaymonth <- fwdshift(1, months)


eom <- which(months!=nextdaymonth) # End of month indices.

eoy <- which(years!=nextdayyear) # End Of Year indices. Note that in R, 2008!=NaN returns FALSE whereas in Matlab 2008~=NaN returns TRUE

annret <- calculateReturns(cl[eoy,], 1) # annual returns
annret <- annret[-1,]

monret <- calculateReturns(cl[eom,], 1) # monthly returns
janret <- monret[months[eom]==1,] # January returns
janret <- janret[-(1:2),] # First January does not have preceding year
exitDay <- tday[months==1 & nextdaymonth==2] # Last day of Janurary
# exitDay <- exitDay[-(c(1, length(exitDay)))] # Exclude first January and last January (which has no price on last day)
exitDay <- exitDay[-(c(1))] # Exclude first January and last January (which has no price on last day)

for (y in 1:nrow(annret)) {
  hasData <- which(is.finite(annret[y,])) # pick those stocks with valid annual returns
  sortidx <- order(annret[y, hasData]) # sort stocks based on prior year's returns
  topN <- round(length(hasData)/10) # buy stocks with lowest decile of returns, and vice versa for highest decile
  portRet <- (sum(janret[y, hasData[sortidx[1:topN]]], na.rm=TRUE)-sum(janret[y, hasData[sortidx[(length(sortidx)-topN+1):length(sortidx)]]], na.rm=TRUE))/2/topN-2*onewaytcost # portfolio returns
  msg <- sprintf('Last holding date %s: Portfolio return=%7.4f\n', as.character(exitDay[y+1]), portRet)
  cat(msg)
}

# Last holding date 2006-01-31: Portfolio return=-0.0244
# Last holding date 2007-01-31: Portfolio return=-0.0068
# Last holding date 2008-01-31: Portfolio return= 0.0881