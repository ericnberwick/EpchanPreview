rm(list=ls()) # clear workspace
# setwd("C:/Users/Ernest/Dropbox/Book") # set working directory to where data is

# Need the zoo package for its na.locf function
# install.packages('zoo')
library('zoo')
source('calculateReturns.R')
source('calculateMaxDD.R')
source('backshift.R')

startDate <- 20060101
endDate   <- 20061231

data1 <- read.delim("SPX_op_20071123.txt") # Tab-delimited
op <- data.matrix(data1[, 2:ncol(data1)])
tday <- data.matrix(data1[, 1])

dailyret <- calculateReturns(op, 1)

marketDailyret <- rowMeans(dailyret, na.rm = TRUE) # First few entries should be c(NaN, -0.001131229, -0.010251817, -0.000813797, ...)

weights <- -(dailyret - marketDailyret)
weights <- weights/rowSums(abs(weights), na.rm = TRUE)

pnl <- rowSums(backshift(1, weights)*dailyret, na.rm = TRUE)

testset <- which(tday >= startDate & tday <= endDate)

sharpeRatioTestset <- sqrt(252)*mean(pnl[testset], na.rm = TRUE)/sd(pnl[testset], na.rm = TRUE)
sharpeRatioTestset #  4.850883

# With transaction costs
onewaytcost <- 5/10000 # 5 bps

pnl <- pnl - rowSums(abs(weights-backshift(1, weights))*onewaytcost, na.rm = TRUE)
sharpeRatioTestset <- sqrt(252)*mean(pnl[testset], na.rm = TRUE)/sd(pnl[testset], na.rm = TRUE)
sharpeRatioTestset # 1.015674
