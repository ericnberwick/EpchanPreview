rm(list=ls()) # clear workspace
# setwd("C:/Users/Ernest/Dropbox/Book") # set working directory to where data is
# 1st part of example 3.4
library('zoo')
#source('calculateReturns.R')
source('calculateMaxDD.R')

data1 <- read.csv("IGE.csv") # Comma delimited
data_sort <- data1[order(as.Date(data1[,1], '%m/%d/%Y')),] # sort in ascending order of dates (1st column of data)
adjcls <- data_sort[,ncol('Adj.Close')]
adjcls[ is.nan(adjcls) ] <- NA
mycls <- na.fill(adjcls, type="locf", nan=NA, fill=NA)
dailyret <- diff(mycls)/mycls[1:(length(mycls)-1)]
excessRet <- dailyret - 0.04/252
sharpeRatio <- sqrt(252)*mean(excessRet, na.rm = TRUE)/sd(excessRet, na.rm = TRUE)
sharpeRatio

# 2nd part of example 3.4
data2 <- read.delim("SPY.txt") # Tab-delimited
data_sort <- data2[order(as.Date(data2[,1], '%m/%d/%Y')),] # sort in ascending order of dates (1st column of data)
adjcls <- data_sort[,ncol('Adj.Close')]
adjcls[ is.nan(adjcls) ] <- NA
mycls <- na.fill(adjcls, type="locf", nan=NA, fill=NA)
dailyretSPY <- diff(mycls)/mycls[1:(length(mycls)-1)]
excessRet <- (dailyret - dailyretSPY)/2
informationRatio <- sqrt(252)*mean(excessRet, na.rm = TRUE)/sd(excessRet, na.rm = TRUE)
informationRatio 
# 3rd part of example 3.4
cumret <- cumprod(1+excessRet[!is.nan(excessRet)])-1
plot(cumret)
output <- calculateMaxDD(cumret)
maxDD <- output[1]
maxDD 
maxDDD <- output[2]
maxDDD 
