rm(list=ls()) # clear workspace

source('backshift.R')


data1 <- read.delim("GLD.txt") # Tab-delimited
data_sort1 <- data1[order(as.Date(data1[,1], '%m/%d/%Y')),] # sort in ascending order of dates (1st column of data)
tday1 <- as.integer(format(as.Date(data_sort1[,1], '%m/%d/%Y'), '%Y%m%d'))
adjcls1 <- data_sort1[,ncol(data_sort1)]

data2 <- read.delim("GDX.txt") # Tab-delimited
data_sort2 <- data2[order(as.Date(data2[,1], '%m/%d/%Y')),] # sort in ascending order of dates (1st column of data)
tday2 <- as.integer(format(as.Date(data_sort2[,1], '%m/%d/%Y'), '%Y%m%d'))
adjcls2 <- data_sort2[,ncol(data_sort2)]

# find the intersection of the two data sets
tday <- intersect(tday1, tday2)
adjcls1 <- adjcls1[tday1 %in% tday]
adjcls2 <- adjcls2[tday2 %in% tday]

# determines the hedge ratio on the trainset
result <- lm(adjcls1 ~ 0 + adjcls2 )
hedgeRatio <- coef(result) # 1.64

spread <- adjcls1-hedgeRatio*adjcls2 # spread = GLD - hedgeRatio*GDX 
prevSpread <- backshift(1, as.matrix(spread))
prevSpread <- prevSpread - mean(prevSpread, na.rm = TRUE) 

deltaSpread <- c(NaN, diff(spread)) # Change in spread from t-1 to t

result2 <- lm(deltaSpread ~ 0 + prevSpread )
theta <- coef(result2) 

halflife <- -log(2)/theta #  7.839031