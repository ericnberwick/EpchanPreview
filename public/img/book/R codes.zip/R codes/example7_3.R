rm(list=ls()) # clear workspace
# setwd("C:/Users/Ernest/Dropbox/Book") # set working directory to where data is

# Need the zoo package for its na.locf function
# install.packages('zoo')
# Need the CADFtest package for its CADFtest function
# install.packages('CADFtest')
library('zoo')
library('CADFtest')
source('calculateReturns.R')


data1 <- read.delim("KO.txt") # Tab-delimited
data_sort1 <- data1[order(as.Date(data1[,1], '%m/%d/%Y')),] # sort in ascending order of dates (1st column of data)
tday1 <- as.integer(format(as.Date(data_sort1[,1], '%m/%d/%Y'), '%Y%m%d'))
adjcls1 <- data_sort1[,ncol(data_sort1)]

data2 <- read.delim("PEP.txt") # Tab-delimited
data_sort2 <- data2[order(as.Date(data2[,1], '%m/%d/%Y')),] # sort in ascending order of dates (1st column of data)
tday2 <- as.integer(format(as.Date(data_sort2[,1], '%m/%d/%Y'), '%Y%m%d'))
adjcls2 <- data_sort2[,ncol(data_sort2)]

# find the intersection of the two data sets
tday <- intersect(tday1, tday2)
adjcls1 <- adjcls1[tday1 %in% tday]
adjcls2 <- adjcls2[tday2 %in% tday]

# CADFtest cannot have NaN values in input 
adjcls1 <- zoo::na.locf(adjcls1)
adjcls2 <- zoo::na.locf(adjcls2)

mydata <- list(KO=adjcls1, PEP=adjcls2);

res <- CADFtest(model=KO~PEP, data=mydata, type = "drift", max.lag.X=1)
summary(res) # As the following input shows, p-value is about 0.16, hence we cannot reject null hypothesis.

# Covariate Augmented DF test 
# CADF test
# t-test statistic:                          -2.2255225
# estimated rho^2:                            0.8249085
# p-value:                                    0.1612782
# Max lag of the diff. dependent variable:    1.0000000
# Max lag  of the stationary covariate(s):    1.0000000
# Max lead of the stationary covariate(s):    0.0000000
# 
# Call:
#   dynlm(formula = formula(model), start = obs.1, end = obs.T)
# 
# Residuals:
#   Min      1Q  Median      3Q     Max 
# -4.7552 -0.0694 -0.0059  0.0576  4.5976 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)  0.0060546  0.0071439   0.848    0.397    
# L(y, 1)     -0.0011457  0.0005148  -2.226    0.161    
# L(d(y), 1)   0.0518074  0.0102210   5.069  4.1e-07 ***
#   L(X, 0)      0.5359345  0.0127566  42.012  < 2e-16 ***
#   L(X, 1)     -0.5348523  0.0127698 -41.884  < 2e-16 ***
#   ---
#   Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
# 
# Residual standard error: 0.436 on 7828 degrees of freedom
# Multiple R-squared:  0.1852,  Adjusted R-squared:  0.1848 
# F-statistic:   593 on 3 and 7828 DF,  p-value: < 2.2e-16


# determines the hedge ratio
lmresult <- lm(KO ~ 0 + PEP, mydata  )
hedgeRatio <- coef(lmresult) # 1.011409 
z <- residuals(lmresult) # The residuals should be stationary (mean-reverting)
plot(z) # This should produce a chart similar to Figure 7.5.

# A test for correlation
dailyReturns <- calculateReturns(cbind(adjcls1, adjcls2), 1)
result <- cor.test(dailyReturns[,1], dailyReturns[,2]) 
result # correlation coefficient is 0.4849239, with p-value < 2.2e-16, definitely correlated!

# Pearson's product-moment correlation

# data:  dailyReturns[, 1] and dailyReturns[, 2]
# t = 49.0707, df = 7832, p-value < 2.2e-16
# alternative hypothesis: true correlation is not equal to 0
# 95 percent confidence interval:
#  0.4678028 0.5016813
# sample estimates:
#       cor 
# 0.4849239 
