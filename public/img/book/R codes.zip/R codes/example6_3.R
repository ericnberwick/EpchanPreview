rm(list=ls()) # clear workspace
# setwd("C:/Users/Ernest/Dropbox/Book") # set working directory to where data is

# Need the zoo package for its na.locf function
# install.packages('zoo')
library('zoo')
source('calculateReturns.R')
source('calculateMaxDD.R')
source('backshift.R')

data1 <- read.delim("OIH.txt") # Tab-delimited
data_sort1 <- data1[order(as.Date(data1[,1], '%m/%d/%Y')),] # sort in ascending order of dates (1st column of data)
tday1 <- as.integer(format(as.Date(data_sort1[,1], '%m/%d/%Y'), '%Y%m%d'))
adjcls1 <- data_sort1[,ncol(data_sort1)]

data2 <- read.delim("RKH.txt") # Tab-delimited
data_sort2 <- data2[order(as.Date(data2[,1], '%m/%d/%Y')),] # sort in ascending order of dates (1st column of data)
tday2 <- as.integer(format(as.Date(data_sort2[,1], '%m/%d/%Y'), '%Y%m%d'))
adjcls2 <- data_sort2[,ncol(data_sort2)]

data3 <- read.delim("RTH.txt") # Tab-delimited
data_sort3 <- data3[order(as.Date(data3[,1], '%m/%d/%Y')),] # sort in ascending order of dates (1st column of data)
tday3 <- as.integer(format(as.Date(data_sort3[,1], '%m/%d/%Y'), '%Y%m%d'))
adjcls3 <- data_sort3[,ncol(data_sort3)]

# merge these data
tday <- union(tday1, tday2)
tday <- union(tday, tday2)
tday <- tday[order(tday)]

adjcls <- matrix(NaN, length(tday), 3)

adjcls[tday %in% tday1, 1] <- adjcls1
adjcls[tday %in% tday2, 2] <- adjcls2
adjcls[tday %in% tday3, 3] <- adjcls3

ret <- calculateReturns(adjcls, 1) # daily returns
excessRet <- ret - 0.04/252 #  excess returns: assume annualized risk free rate is 4%

# annualized mean excess returns
M <- 252*colMeans(excessRet, na.rm = TRUE) # c(0.143479780597111, 0.0560305170502084, -0.0073464585163155)
#  annualized covariance matrix
C<- 252*cov(excessRet, use = "pairwise.complete.obs") 
# 0.11305722  0.01986547	0.01825486
# 0.01986547	0.04263365	0.02689284
#	0.01825486	0.02689284	0.04196684

# Kelly optimal leverage
F <- solve(C) %*% M
# 1.240554
#  1.992328
#	-1.991381

# Maximum annualized compounded growth rate
g <- 0.04+t(F) %*% C %*% F/2 # 0.1921276

# Sharpe ratio of portfolio
S <- sqrt(t(F) %*% C %*% F) #  0.5515933

