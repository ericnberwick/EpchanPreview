rm(list=ls()) # clear workspace

# Need the zoo package for its na.locf function
#install.packages('zoo')
# Need the CADFtest package for its CADFtest function
#install.packages('CADFtest')
library('zoo')
library('CADFtest')

data1 <- read.delim("GLD.txt") # Tab-delimited
data_sort1 <- data1[order(as.Date(data1[,1], '%m/%d/%Y')),] # sort in ascending order of dates (1st column of data)
tday1 <- as.integer(format(as.Date(data_sort1[,1], '%m/%d/%Y'), '%Y%m%d'))
adjcls1 <- data_sort1[,ncol(data_sort1)]

data2 <- read.delim("GDX.txt") # Tab-delimited
data_sort2 <- data2[order(as.Date(data2[,1], '%m/%d/%Y')),] # sort in ascending order of dates (1st column of data)
tday2 <- as.integer(format(as.Date(data_sort2[,1], '%m/%d/%Y'), '%Y%m%d'))
adjcls2 <- data_sort2[,ncol(data_sort2)]

# find the intersection of the two data sets
tday <- intersect(tday1, tday2)
adjcls1 <- adjcls1[tday1 %in% tday]
adjcls2 <- adjcls2[tday2 %in% tday]

# CADFtest cannot have NaN values in input 
adjcls1 <- zoo::na.locf(adjcls1)
adjcls2 <- zoo::na.locf(adjcls2)

mydata <- list(GLD=adjcls1, GDX=adjcls2);

trainset <- 1:252

res <- CADFtest(model=GLD~GDX, data=mydata, type = "drift", max.lag.X=1, subset=trainset)
summary(res) # As the following input shows, p-value is about 0.005, hence we can reject null hypothesis of no cointegration at 99.5% level.

# Covariate Augmented DF test 
# CADF test
# t-test statistic:                          -3.240868894
# estimated rho^2:                            0.260414676
# p-value:                                    0.004975155
# Max lag of the diff. dependent variable:    1.000000000
# Max lag  of the stationary covariate(s):    1.000000000
# Max lead of the stationary covariate(s):    0.000000000
# 
# Call:
#   dynlm(formula = formula(model), start = obs.1, end = obs.T)
# 
# Residuals:
#   Min       1Q   Median       3Q      Max 
# -2.70728 -0.26235  0.00595  0.29684  1.47164 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept) -0.07570    0.29814  -0.254  0.79970    
# L(y, 1)     -0.03817    0.01178  -3.241  0.00498 ** 
#   L(d(y), 1)   0.08542    0.03077   2.776  0.00578 ** 
#   L(X, 0)      0.75428    0.02802  26.919  < 2e-16 ***
#   L(X, 1)     -0.68942    0.03161 -21.812  < 2e-16 ***
#   ---
#   Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
# 
# Residual standard error: 0.474 on 378 degrees of freedom
# Multiple R-squared:  0.6577,  Adjusted R-squared:  0.6541 
# F-statistic: 241.8 on 3 and 378 DF,  p-value: < 2.2e-16

# determines the hedge ratio
lmresult <- lm(GLD ~ 0 + GDX, mydata, subset=trainset    )
hedgeRatio <- coef(lmresult) # 1.639523
z <- residuals(lmresult) # The residuals should be stationary (mean-reverting)
plot(z) # This should produce a chart similar to Figure 7.4.
